<?php

setcookie('identifier', 'Webtech Project', time()+10);
echo "Cookie has been set";

  echo "<br><a href='view.php'>Cookies</a>";

?>