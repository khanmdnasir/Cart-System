
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Json Example</title>
	
	</head>
<body>
    <h1>Show Information</h1>
	 <button id="showInfo">Show Information</button>  
    <div id="showme"></div>
	
    <script>
        document.getElementById("showInfo").addEventListener('click', onProcess);

        function onProcess(){
            var req = new XMLHttpRequest();
            req.open('GET', 'https://api.github.com/users', true);
            req.onload = function() {
                if(req.status==200){
                  var people = JSON.parse(req.responseText)
                  var display= '';
                  for(var i in people){
                     display += '<ol>'+
                   '<li>ID: <span id="class-one">'+people[i].id+'<span></li>' +
                   '<li>Login: <span id="class-one">'+people[i].login+'<span></li>' +
                    '</ol>';
                   document.getElementById('showme').innerHTML = display;
                   }

                }

            }
            req.send();
        }
    </script>
	
</body>
</html>