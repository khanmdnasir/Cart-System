<?php

echo $_COOKIE['identifier']; // will print AIUB. Try refreshing this page after 10 sec.

echo "<br><a href='json.php'>User Information</a>";

?>