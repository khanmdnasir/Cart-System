<?php
session_start();
echo $_COOKIE['identifier'];
if(isset($_SESSION['favcolor1'])) {
   
    session_unset();
    session_destroy();
    
    echo "<br> All session variables are now removed, and the session is destroyed.";
}
?>



