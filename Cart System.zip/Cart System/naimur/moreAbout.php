
<!DOCTYPE html>
<html lang="en">
</head>

<style>
        #grab{
	            text-align: center;
                margin-left: 550px;
                 margin-top: 30px;
             }
        ul {
            border: 2px purple solid;
            align-items: center;
            flex-wrap: wrap;
            flex-basis:50%;
            padding-left:25px;
            padding-right:25px ;
            margin-bottom: 50px;
            box-sizing:border-box;
        }
        li {
            padding-left: 2%;
            color: green;
            
        }
    </style>
</head>
<body>
<button id="grab">Display</button>
 <div id="universities"></div>
    <script>

    document.getElementById('grab').addEventListener('click', showValues);
    function showValues() {
        var req = new XMLHttpRequest();
        req.open('GET','returnHandler.php',true );

        req.onload = function(){
            if(req.status==200){
            var namez = JSON.parse(req.responseText);
            var display = '';
           
            for (var i in namez){
                display += '<ul>'+
                    '<li>Name: '+namez[i].Name+'</li>'+
                    '<li>Age: '+namez[i].Age+'</li>'+
                    '<li>Work Exprience: '+namez[i].Exprience+'</li>'+'</ul>';
            }

           
            document.getElementById('universities').innerHTML=display;
        }
    }
        req.send();
    }
    </script>
</body>
</html>