<?php
session_start();
echo $_COOKIE['identifier'];
if(isset($_SESSION['userId'])) {
    echo "<br> Hello ".$_SESSION['userId'];
    session_unset();
    session_destroy();
    
    echo "<br> All session variables are now removed, and the session is destroyed.";
}
?>



