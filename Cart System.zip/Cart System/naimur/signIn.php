<?php
$db = mysqli_connect("localhost", "project", "12345", "hr");
if(isset($_POST['login'])) {
    session_start();
    $userId = $_POST['userId'];
    $password = ($_POST['password']);
    $sql = "SELECT * FROM hrmember WHERE userId='$userId' AND password='$password'";
    $verify = mysqli_query($db, $sql);

    if(mysqli_num_rows($verify) == 1){
     $_SESSION['userId'] = $userId;
     header("location:show.php");
    }
    else{
        echo "Incorrect email/password combination";
    }
}
setcookie('identifier', 'Welcome to the Page', time()+10);
?>

<!DOCTYPE html>
<html>
    <head>
    </head>

<style>
       #login1{
           
           text-align:center;
           color:#003300;
           margin-top:10%;
       }
       
        #table1{
           
                background-color:#e6f7ff;
                color: black;
                margin-left:40%;
	            padding: 10px;
                border:groove;
                border-color: cornsilk;
                border-width:5px;
                font-size: 20px;
                font-style:bold;
                letter-spacing: 1px;
        }
       
    </style>
</head>
    </head>
    <body>
        <h1 id="login1">Login</h1>
        <form method="post" action="signIn.php">
            <table id="table1">
               
                <tr>
                    <td>UserId</td>
                    <td><input type="userId" name="userId" required></td>
                </tr>
                <tr>
                    <td>Password</td>
                    <td><input type="password" name="password" required></td>
                </tr>
                <tr>
                    <td><input type="submit" name="login" value="Login" required></td>
                </tr>
            </table>
            
        </form>
    </body>
</html>